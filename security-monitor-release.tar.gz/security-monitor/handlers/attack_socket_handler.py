# -*- coding: utf-8 -*-
# @Author blackrat  wangmingbo@zhongan.io
# @Time 2019-06-03 12:29

import json
from base_socket_handler import BaseSocketHandler
from data.mock_data import attack_data
from multiprocessing import Process
from tornado.ioloop import PeriodicCallback
from config import UPDATE_PERIODS
from biz.hkbea_soc import HkbeaSoc


class AttackSocketHandler(BaseSocketHandler):

    def open(self):
        self.logger.info("Socket connection open")
        Process(target=self.send_attack_data, args=()).start()

        self.callbacks = [
            PeriodicCallback(self.send_attack_data, UPDATE_PERIODS * 1000),
        ]
        for callback in self.callbacks:
            callback.start()

    def send_attack_data(self):
        try:
            hkes = HkbeaSoc()
            attack_data = hkes.attacks(hours=1)
            self.logger.info(json.dumps(attack_data))
            self.write_message(json.dumps(attack_data))
        except Exception, e:
            self.logger.error("send_statistics write message error:%s", e)




