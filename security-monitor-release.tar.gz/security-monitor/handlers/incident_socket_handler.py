# -*- coding: utf-8 -*-
# @Author blackrat  wangmingbo@zhongan.io
# @Time 2019-06-03 12:31

import json
from base_socket_handler import BaseSocketHandler
from data.mock_data import incident_data
from multiprocessing import Process
from tornado.ioloop import PeriodicCallback
from biz.hkbea_soc import HkbeaSoc
from config import INCIDENT_PERIODS

class IncidentSocketHandler(BaseSocketHandler):

    def open(self):
        self.logger.info("Socket connection open")
        Process(target=self.send_incident_data, args=()).start()
        self.callbacks = [
            PeriodicCallback(self.send_incident_data, INCIDENT_PERIODS * 1000),
        ]
        for callback in self.callbacks:
            callback.start()

    def send_incident_data(self):
        try:
            hkes = HkbeaSoc()
            incident_data = hkes.last_incident(INCIDENT_PERIODS)
            if len(incident_data) > 0:
                self.logger.info(json.dumps(incident_data))
                self.write_message(json.dumps(incident_data[0]))
        except Exception, e:
            self.logger.error("send_statistics write message error:%s", e)

