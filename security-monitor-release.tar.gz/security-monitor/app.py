# -*- coding: utf-8 -*-
# @Author blackrat  wangmingbo@zhongan.io
# @Time 2019-06-03 12:15

import os,sys,logging
reload(sys)
sys.setdefaultencoding('utf8')

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir)))
import tornado.ioloop
import tornado.httpserver
import tornado.web
from utils.log import log_setting
from tornado.options import define, options
from urls_map import urls

settings = {
    "static_url_prefix": "/statics/",
    "static_path": os.path.join(os.path.dirname(__file__), "statics"),
    "template_path": os.path.join(os.path.dirname(__file__), "templates"),
    "cookie_secret": "44e4b5d8de5051cc89cf4df701ad7657",
    "autoescape": None,
    "gzip": True,
    "debug": False,
}


if __name__ == '__main__':

    define("port", default=8300, help='run on the given port', type=int)
    define("mode", default="d", help="d/r")
    #解析命令
    options.parse_command_line()
    #设置运行模式
    settings["debug"] = False if options.mode == "d" else True
    #设置日志记录模式
    log_setting("security-monitor", verbose_level=4, runmode=options.mode)

    application = tornado.web.Application(handlers=urls, **settings)
    http_server = tornado.httpserver.HTTPServer(application, xheaders=True)
    http_server.listen(options.port, '0.0.0.0')
    print "web start http://0.0.0.0:{0}/".format(options.port)
    tornado.ioloop.IOLoop.instance().start()
