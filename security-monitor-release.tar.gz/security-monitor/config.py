# -*- coding: utf-8 -*-
# @Author: wangmingbo <blackrat>
# @Date:   2016-10-12
# @Email:  wangmingbo@zhongan.com
# @Last modified by:   blackrat
# @Last modified time: 2016-10-13
# @License: Copyright (c) 2016 by zhongan.com Corporation. All Rights Reserved.

import os
# netcops application root path
ROOT_PATH = os.path.normpath(os.path.join(os.path.abspath(os.path.dirname(__file__)), "."))


# 数据更新周期/秒
UPDATE_PERIODS = 30

# 应急事件更新事件周期/秒
INCIDENT_PERIODS = 20

# es 时间格式
DATEFORMAT = "%Y-%m-%d %H:%M:%S"
TIMEFORMAT = "%H:%M:%S"
ES_DATE_FORMAT_1 = '%Y-%m-%dT%H:%M:%S.%fZ'

#elasticsearch
#ELASTICSEARCH_HOSTS = ["10.139.113.60:9200","10.139.115.31:9200","10.139.115.60:9200"]
#ELASTICSEARCH_HOSTS = ["10.139.102.16:9800", "10.139.104.33:9800", "10.139.105.44:9800", "10.139.113.60:9800", "10.139.115.31:9800", "10.139.115.60:9800"]
ELASTICSEARCH_HOSTS = ["127.0.0.1:9200"]



#Mangodb
MONGODB_SERVER = "tech-tst-mongo.zhonganinfo.com"
MONGODB_PORT = 27017
MONGODB_DB = "tian_soc"
MONGODB_PASS = 'tian_soc_dev_7b0208'
MONGODB_USER = 'tian_soc_dev'




