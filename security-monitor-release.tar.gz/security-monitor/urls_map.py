# -*- coding: utf-8 -*-
# @Author: wangmingbo <blackrat>
# @Date:   2016-10-12
# @Email:  wangmingbo@zhongan.com
# @Last modified by:   blackrat
# @Last modified time: 2016-10-12
# @License: Copyright (c) 2016 by zhongan.com Corporation. All Rights Reserved.

from handlers.attack_socket_handler import AttackSocketHandler
from handlers.statistics_socket_handler import StatisticsSocketHandler
from handlers.incident_socket_handler import IncidentSocketHandler
from handlers.demo_handler import DemoHandler

urls = [
    (r"/", DemoHandler),
    (r"/socket/v1/statistics", StatisticsSocketHandler),
    (r"/socket/v1/attacks", AttackSocketHandler),
    (r"/socket/v1/incident", IncidentSocketHandler)
]