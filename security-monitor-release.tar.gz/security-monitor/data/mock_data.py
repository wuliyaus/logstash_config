# -*- coding: utf-8 -*-
# @Author blackrat  wangmingbo@zhongan.io
# @Time 2019-06-03 12:43

import json
import random

statistics_data = {
    'attack_countries': [
        {'cca2': 'CN', 'name': u'中国', 'count': 1313213213121},
        {'cca2': 'US', 'name': u'美国', 'count': 999991231231},
        {'cca2': 'CA', 'name': u'加拿大', 'count': 8112312311},
        {'cca2': 'JP', 'name': u'日本', 'count': 70000123},
        {'cca2': 'TH', 'name': u'泰国', 'count': 66512111}
    ],
    'attack_types': [
        {'name': u'web scanner', 'count': 8000000},
        {'name': u'DDoS Attack', 'count': 7800000},
        {'name': u'Backdoor', 'count': 6711111},
        {'name': u'Bot Spider', 'count': 6511111},
        {'name': u'Virus', 'count': 1231231}
    ],
    'attack_trends': [
        {
            'time': '01:00',
            'waf': 100,
            'ips': 300,
            'ads': 600,
            'apt': 10
        },
        {
            'time': '02:00',
            'waf': 200,
            'ips': 400,
            'ads': 500,
            'apt': 9
        },
        {
            'time': '03:00',
            'waf': 600,
            'ips': 200,
            'ads': 900,
            'apt': 25
        },
        {
            'time': '04:00',
            'waf': 201,
            'ips': 1002,
            'ads': 3001,
            'apt': 1
        },
        {
            'time': '05:00',
            'waf': 901,
            'ips': 2121,
            'ads': 1212,
            'apt': 0
        },
        {
            'time': '06:00',
            'waf': 100,
            'ips': 300,
            'ads': 600,
            'apt': 3
        },
        {
            'time': '07:00',
            'waf': 123,
            'ips': 312,
            'ads': 555,
            'apt': 1
        },
        {
            'time': '08:00',
            'waf': 444,
            'ips': 555,
            'ads': 666,
            'apt': 7
        },
        {
            'time': '09:00',
            'waf': 123,
            'ips': 321,
            'ads': 654,
            'apt': 4
        },
        {
            'time': '10:00',
            'waf': 222,
            'ips': 344,
            'ads': 877,
            'apt': 0
        }
    ],
    'security_response': {
        'change_count': -10,
        'change_rate': -0.003,
        'total': 610,
        'total_fixed': 500,
        'day_count': [
            {
                'time': '2019-06-01',
                'fixed': 3,
                'unfix': 0
            },
            {
                'time': '2019-06-02',
                'fixed': 1,
                'unfix': 0
            },
            {
                'time': '2019-06-03',
                'fixed': 3,
                'unfix': 2
            },
            {
                'time': '2019-06-04',
                'fixed': 4,
                'unfix': 0
            },
            {
                'time': '2019-06-05',
                'fixed': 3,
                'unfix': 1
            },
            {
                'time': '2019-06-06',
                'fixed': 3,
                'unfix': 3
            },
            {
                'time': '2019-06-07',
                'fixed': 2,
                'unfix': 2
            },
        ]
    },
    'device_types': {
        'waf': {"device_count": 3, "alarms": 100, "blocks": 10},
        'ips': {"device_count": 5, "alarms": 3000, "blocks": 1000},
        'ads': {"device_count": 3, "alarms": 1876, "blocks": 876},
        'apt': {"device_count": 8, "alarms": 918, "blocks": 0}
    }
}


attack_data = [
    {'attack_type': 'SQLi', 'ip': '165.121.213.111', 's_region': u'中国 北京' ,'s_geo_point': [116.4,39.9], 'time': '10:23:29', 'level': 4, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'XSS', 'ip': '165.121.213.112', 's_region': u'加拿大 多伦多' ,'s_geo_point': [-75.42,45.27], 'time': '10:23:28', 'level': 3, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'DDoS', 'ip': '165.121.213.1', 's_region': u'俄罗斯 莫斯科' ,'s_geo_point': [37.35,55.45], 'time': '10:23:28', 'level': 2, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'APT', 'ip': '165.121.213.2', 's_region': u'俄罗斯 莫斯科' ,'s_geo_point': [37.35,55.45], 'time': '10:23:27', 'level': 2, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'Scanner', 'ip': '165.121.213.3', 's_region': u'俄罗斯 莫斯科' ,'geo_point': [37.35,55.45], 'time': '10:23:01', 'level': 1, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'Webshell', 'ip': '165.121.213.4', 's_region': u'苏丹' ,'s_geo_point': [32.35,15.31], 'time': '10:23:00', 'level': 4, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'Info Leaks', 'ip': '165.121.213.5', 's_region': u'西班牙 马德里' ,'s_geo_point': [-3.45,40.25], 'time': '10:20:19','level': 3, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'SQLi', 'ip': '165.121.213.6', 's_region': u'西班牙 马德里' ,'s_geo_point': [-3.45,40.25], 'time': '10:20:11', 'level': 2, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'XSS', 'ip': '165.121.213.7', 's_region': u'西班牙 马德里' ,'s_geo_point': [-3.45,40.25], 'time': '10:20:01', 'level': 3, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'DDoS', 'ip': '165.121.213.8', 's_region': u'瑞典' ,'s_geo_point': [18.03,59.20], 'time': '10:10:19', 'level': 4, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'Backdoor', 'ip': '165.121.213.9', 's_region': u'以色列' ,'s_geo_point': [35.12,31.47], 'time': '09:20:19', 'level': 4, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]},
    {'attack_type': 'Virus', 'ip': '165.121.213.10', 's_region': u'以色列' ,'s_geo_point': [35.12,31.47], 'time': '09:11:12', 'level': 3, 'd_region': u'中国 上海' ,'d_geo_point': [121.48,31.23]}
]

incident_data = {
    'event_name': u'未通过堡垒机登录服务器',
    'handler': u'Leo',
    'handler_team': u'数据组',
    'level': random.randint(1, 4)
}


print json.dumps(statistics_data)
