# -*- coding: utf-8 -*-
# @Author blackrat  wangmingbo@zhongan.io
# @Time 2019-06-03 12:25


from utils.log import log_setting

from tornado.websocket import WebSocketHandler


class BaseSocketHandler(WebSocketHandler):

    def __init__(self, application, request, **kwargs):
        self.logger = log_setting("security-monitor")
        self.callbacks = []
        WebSocketHandler.__init__(self, application, request, **kwargs)

    # 允许跨域请求
    def check_origin(self, origin):
        return True

    def open(self):
        self.number = 0
        self.logger.info("Socket connection open")
        pass

    def on_close(self, code=None, reason=None):
        self.logger.info("Socket connection closed")
        for callback in self.callbacks:
            try:
                callback.stop()
            except Exception, e:
                self.logger.error("Try to close the PeriodicCallback failed %s", e)

