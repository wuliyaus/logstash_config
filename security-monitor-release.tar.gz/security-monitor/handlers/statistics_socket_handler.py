# -*- coding: utf-8 -*-
# @Author blackrat  wangmingbo@zhongan.io
# @Time 2019-06-03 12:29

import json
from base_socket_handler import BaseSocketHandler
from data.mock_data import statistics_data
from multiprocessing import Process
from tornado.ioloop import PeriodicCallback
from biz.hkbea_soc import HkbeaSoc
from config import UPDATE_PERIODS


class StatisticsSocketHandler(BaseSocketHandler):

    def open(self):
        self.logger.info("Socket connection open")
        Process(target=self.send_statistics, args=()).start()

        self.callbacks = [
            PeriodicCallback(self.send_statistics, UPDATE_PERIODS * 1000),
        ]
        for callback in self.callbacks:
            callback.start()

    def send_statistics(self):
        try:

            hkes = HkbeaSoc()
            statistics_data = {
                'attack_countries': hkes.attack_countries(days=7),
                'attack_types': hkes.attack_types(days=7),
                'attack_trends': hkes.attack_trends(hours=12, points=12),
                'device_types': hkes.dev_stastics(hours=12),
                'security_response': hkes.security_response_stastics(days=7)
            }
            self.logger.info(json.dumps(statistics_data))
            self.write_message(json.dumps(statistics_data))
        except Exception, e:
            self.logger.error("send_statistics write message error:%s", e)


