# -*- coding: utf-8 -*-
# author blackrat  wangmingbo@zhongan.com
# create date 16/1/28

import os
import logging
from logging.handlers import RotatingFileHandler
from config import ROOT_PATH

def log_setting(name, verbose_level=4, runmode='d', stdout_switch=True):
    logger = logging.getLogger(name)
    if not len(logger.handlers):
        log_dir = os.path.join(ROOT_PATH,"logs")
        if not os.path.isdir(log_dir):
                os.mkdir(log_dir)

        logger.setLevel(logging.DEBUG)

        log_file_name = os.path.join(log_dir, name +"."+ runmode + ".log")
        err_file_name = os.path.join(log_dir, name + '.err.'+ runmode + ".log")
        level_map = [logging.CRITICAL, logging.ERROR, logging.WARNING, logging.INFO, logging.DEBUG]

        # 定义一个RotatingFileHandler，最多备份5个日志文件，每个日志文件最大10M
        Rthandler = RotatingFileHandler(log_file_name, maxBytes=10 * 1024 * 1024, backupCount=5)
        Rthandler.setLevel(level_map[verbose_level])

        # 该handler 把Error以上错误信息记录到日志
        Ethandler = RotatingFileHandler(err_file_name, maxBytes=10 * 1024 * 1024, backupCount=1)
        Ethandler.setLevel(logging.ERROR)


        # 在创建一个handler，用于输出到控制台
        ch = logging.StreamHandler()
        ch.setLevel(level_map[verbose_level])

         # 定义handler的输出格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s %(process)d:%(thread)d(%(threadName)s) - [%(funcName)s: %(filename)s,%(lineno)d] - %(levelname)s - %(message)s')
        Rthandler.setFormatter(formatter)
        Ethandler.setFormatter(formatter)
        ch.setFormatter(formatter)

        # 给logger添加handler
        logger.addHandler(Rthandler)
        if stdout_switch:
            logger.addHandler(ch)
        logger.addHandler(Ethandler)
    return logger





