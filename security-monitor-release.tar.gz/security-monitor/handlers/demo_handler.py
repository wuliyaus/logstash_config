# -*- coding: utf-8 -*-
# @Author blackrat  wangmingbo@zhongan.io
# @Time 2019-06-03 15:08

from tornado.web import RequestHandler


class DemoHandler(RequestHandler):

    def get(self):
        return self.render('demo.html')

