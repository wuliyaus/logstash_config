# -*- coding: utf-8 -*-
# author blackrat  wangmingbo@zhongan.com
# create date 17/11/9


import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../")))
from pymongo import MongoClient
from config import MONGODB_DB, MONGODB_PASS, MONGODB_PORT, MONGODB_SERVER, MONGODB_USER
from utils.log import log_setting

class Mongodb:

    def __init__(self):
        self.log = log_setting("security_monitor")
        self.client = None
        self.db = None

    def __del__(self):
        self.close()

    def conn(self,
             host=MONGODB_SERVER,
             port=MONGODB_PORT,
             user=MONGODB_USER,
             password=MONGODB_PASS,
             db=MONGODB_DB):
        mongo_uri = "mongodb://{username}:{password}@{host}:{port}/{db}".format(
            username=user,
            password=password,
            host=host,
            port=port,
            db=db)
        if self.client == None:
            self.client = MongoClient(mongo_uri)
        self.db = self.client[db]
        return self.db

    def close(self):
        try:
            self.db = None
            self.client.close()
        except Exception, e:
            pass

if __name__ == "__main__":

        mongo = Mongodb()
        db = mongo.conn()
        aaa = db.incident.find({'name': 'test'})
        print aaa.count()