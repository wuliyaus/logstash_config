# -*- coding: utf-8 -*-
# @Author blackrat  wangmingbo@zhongan.io
# @Time 2019-06-16 14:37

from config import ELASTICSEARCH_HOSTS
from config import ROOT_PATH
from data.mongodb import Mongodb
from elasticsearch import Elasticsearch
from elasticsearch_dsl import Search, Q, MultiSearch
from datetime import datetime, timedelta
from bson.son import SON
import json



class HkbeaSoc(object):

    _data_path = ROOT_PATH + '/biz/countries.json'

    def __init__(self):
        self.es = Elasticsearch(hosts=ELASTICSEARCH_HOSTS, timeout=120)
        # 加载国家数据
        self.load_country_data()

    def load_country_data(self):
        with open(self._data_path, 'r') as f:
            self._country_data = json.load(f)


    def attacks(self, hours=1):
        attacks = []
        same_attacks = {}
        end_time = datetime.now() #datetime.strptime('2019-06-12 01:00:00', '%Y-%m-%d %H:%M:%S')
        start_time = end_time - timedelta(hours=hours)
        start_time_str = start_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        end_time_str = end_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        waf_q = Q('bool', must=[
            Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}}),
            Q('terms', action=['Reject', 'Accept', 'Forward'])
        ])
        ips_q = Q('bool', must=[
            Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}}),
            Q('terms', action=['Permit'])
        ])
        ads_q = Q('bool', must=[
            Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}}),
        ])

        waf_search = Search(using=self.es, index='titan-secdev-wafsec-*').query(waf_q).sort('-@timestamp')[:40]
        ips_search = Search(using=self.es, index='titan-secdev-tpips-*').query(ips_q).sort('-@timestamp')[:40]
        ads_search = Search(using=self.es, index='titan-secdev-adssec-*').query(ads_q).sort('-@timestamp')[:20]

        try:
            waf_response = waf_search.execute()
            for h in waf_response:
                d_region = 'China Shanghai'
                d_geo_point = [36.6683, 116.9972]
                if h.d_geoip:
                    d_region = '{0} {1}'.format(
                        h.d_geoip.country_name,
                        h.d_geoip.city_name if hasattr(h.d_geoip, 'city_name') else getattr(h.d_geoip, 'region_name', '')
                    )
                    d_geo_point = [h.d_geoip.location.lon, h.d_geoip.location.lat]

                if h.s_geoip:
                    s_region = '{0} {1}'.format(
                        h.s_geoip.country_name,
                        h.s_geoip.city_name if hasattr(h.s_geoip, 'city_name') else getattr(h.s_geoip, 'region_name', '')
                    )
                    s_geo_point = [h.s_geoip.location.lon, h.s_geoip.location.lat]
                else:
                    continue

                timestamp = datetime.strptime(h['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                level = 1
                if h.alertlevel == 'HIGH':
                    level = 4
                if h.alertlevel == 'MEDIUM':
                    level = 3
                if h.alertlevel == 'LOW':
                    level = 2

                attack = {
                    'attack_type': h.event_type,
                    'ip': h.src_ip,
                    's_region': s_region,
                    's_geo_point': s_geo_point,
                    'time': timestamp.strftime('%H:%M:%S'),
                    'timestamp': timestamp,
                    'level': level,
                    'd_region': d_region,
                    'd_geo_point': d_geo_point,
                }
                if not same_attacks.get(attack['attack_type'] + '#' + attack['s_region'], False):
                    attacks.append(attack)
                    same_attacks[attack['attack_type'] + '#' + attack['s_region']] = True

            ips_response = ips_search.execute()
            for h in ips_response:
                d_region = 'China Shanghai'
                d_geo_point = [36.6683, 116.9972]
                if h.d_geoip:
                    d_region = '{0} {1}'.format(
                        h.d_geoip.country_name,
                        h.d_geoip.city_name if hasattr(h.d_geoip, 'city_name') else getattr(h.d_geoip, 'region_name', '')
                    )
                    d_geo_point = [h.d_geoip.location.lon, h.d_geoip.location.lat]

                if h.s_geoip:
                    s_region = '{0} {1}'.format(
                        h.s_geoip.country_name,
                        h.s_geoip.city_name if hasattr(h.s_geoip, 'city_name') else getattr(h.s_geoip, 'region_name', '')
                    )
                    s_geo_point = [h.s_geoip.location.lon, h.s_geoip.location.lat]
                else:
                    continue

                timestamp = datetime.strptime(h['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')

                if h.alertlevel == 'Critical':
                    level = 4
                elif h.alertlevel == 'Major':
                    level = 3
                elif h.alertlevel == 'Minor':
                    level = 2
                else:
                    level = 1

                attack = {
                    'attack_type': h.sig_name,
                    'ip': h.src_ip,
                    's_region': s_region,
                    's_geo_point': s_geo_point,
                    'time': timestamp.strftime('%H:%M:%S'),
                    'timestamp': timestamp,
                    'level': level,
                    'd_region': d_region,
                    'd_geo_point': d_geo_point
                }
                if not same_attacks.get(attack['attack_type'] + '#' + attack['s_region'], False):
                    attacks.append(attack)
                    same_attacks[attack['attack_type'] + '#' + attack['s_region']] = True

            ads_response = ads_search.execute()
            for h in ads_response:
                d_region = 'China Shanghai'
                d_geo_point = [36.6683, 116.9972]
                if h.d_geoip:
                    d_region = '{0} {1}'.format(
                        h.d_geoip.country_name,
                        h.d_geoip.city_name if hasattr(h.d_geoip, 'city_name') else getattr(h.d_geoip, 'region_name', '')
                    )
                    d_geo_point = [h.d_geoip.location.lon, h.d_geoip.location.lat]

                if h.s_geoip:
                    s_region = '{0} {1}'.format(
                        h.s_geoip.country_name,
                        h.s_geoip.city_name if hasattr(h.s_geoip, 'city_name') else getattr(h.s_geoip, 'region_name', '')
                    )
                    s_geo_point = [h.s_geoip.location.lon, h.s_geoip.location.lat]
                else:
                    continue
                timestamp = datetime.strptime(h['@timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                level = 1
                attack = {
                    'attack_type': h.attack,
                    'ip': h.src_ip,
                    's_region': s_region,
                    's_geo_point': s_geo_point,
                    'time': timestamp.strftime('%H:%M:%S'),
                    'timestamp': timestamp,
                    'level': level,
                    'd_region': d_region,
                    'd_geo_point': d_geo_point
                }
                if not same_attacks.get(attack['attack_type'] + '#' + attack['s_region'], False):
                    attacks.append(attack)
                    same_attacks[attack['attack_type'] + '#' + attack['s_region']] = True

        except Exception, e:
            print "query attacks failed %s", e

        attacks.sort(key=lambda el: el['timestamp'], reverse=True)
        for at in attacks:
            del at['timestamp']

        return attacks


    def attack_countries(self, days=7):

        countries = []

        end_time = datetime.now() #datetime.strptime('2019-06-13 01:00:00', '%Y-%m-%d %H:%M:%S')
        start_time = end_time - timedelta(days=days)
        start_time_str = start_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        end_time_str = end_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')

        attack_q =  Q('bool', must=[
            Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}}),
        ])
        country_search = Search(using=self.es,
                                index='titan-secdev-wafsec-*,titan-secdev-tpips-*,titan-secdev-adssec-*').query(attack_q)[:0]
        country_search.aggs.bucket('per_country', 'terms', field='s_geoip.country_name', size=10)
        try:
            country_resposne = country_search.execute()
            for res in country_resposne.aggregations.per_country.buckets:
                for item in self._country_data:
                    if item['name']['common'] == res.key:
                        country = {
                            'cca2': item['cca2'],
                            'name': res.key,
                            'count': res.doc_count
                        }
                        countries.append(country)
        except Exception, e:
            print "query attack_countries failed %s", e

        return countries[:5]

    def attack_types(self, days=7):
        attack_types = []
        end_time = datetime.now() #datetime.strptime('2019-06-13 01:00:00', '%Y-%m-%d %H:%M:%S')
        start_time = end_time - timedelta(days=days)
        start_time_str = start_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        end_time_str = end_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')

        waf_q = Q('bool', must=[
            Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}}),
            Q('terms', action=['Reject', 'Accept', 'Forward'])
        ])
        ips_q = Q('bool', must=[
            Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}}),
            Q('terms', action=['Permit'])
        ])
        ads_q = Q('bool', must=[
            Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}})
        ])

        waf_search = Search(using=self.es, index='titan-secdev-wafsec-*').query(waf_q)[:0]
        waf_search.aggs.bucket('per_event_type', 'terms', field='event_type', size=20)

        tips_search = Search(using=self.es, index='titan-secdev-tpips-*').query(ips_q)[:0]
        tips_search.aggs.bucket('per_sig_name', 'terms', field='sig_name', size=20)

        ads_search = Search(using=self.es, index='titan-secdev-adssec-*').query(ips_q)[:0]
        ads_search.aggs.bucket('per_sig_name', 'terms', field='attack', size=20)

        try:
            waf_response = waf_search.execute()
            for res in waf_response.aggregations.per_event_type.buckets:
                t = {
                    'name': res.key,
                    'count': res.doc_count
                }
                attack_types.append(t)
            tips_response = tips_search.execute()
            for res in tips_response.aggregations.per_sig_name.buckets:
                name = res.key.split(':')[-1]
                t = {
                    'name': name,
                    'count': res.doc_count
                }
                attack_types.append(t)
            for res in ads_search.aggregations.per_sig_name.buckets:
                t = {
                    'name': res.key,
                    'count': res.doc_count
                }
                attack_types.append(t)
        except Exception, e:
            print "query attack_types failed %s", e
        attack_types.sort(key=lambda el: el['count'], reverse=True)
        return attack_types[:5]

    def attack_trends(self, hours=12, points=12):
        attack_trends = []
        end_time = datetime.now() #datetime.strptime('2019-06-12 06:00:00', '%Y-%m-%d %H:%M:%S')
        start_time = end_time - timedelta(hours=hours)
        start_time_str = start_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        end_time_str = end_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        q = Q('bool',
              must=[Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}})]
              )

        interval = float(hours) / float(points)
        if interval < 1:
            interval_str = '{0}m'.format(int(60*interval))
        else:
            interval_str = '{0}h'.format(int(interval))

        trends_search = Search(
            using=self.es,
            index='titan-secdev-wafsec-*,titan-secdev-tpips-*,titan-secdev-adssec-*'
        ).query(q)[:0]
        trends_search.\
            aggs.bucket('count_per_day', 'date_histogram',
                        field='@timestamp',
                        interval=interval_str,
                        extended_bounds={"min": start_time_str, "max": end_time_str}).\
            bucket('count_per_dev', 'terms', field='appName', size=3)

        try:
            trends_response = trends_search.execute()
            print json.dumps(trends_response.to_dict())

            for t in trends_response.aggregations.count_per_day.buckets:
                tm = datetime.strptime(t.key_as_string, '%Y-%m-%dT%H:%M:%S.%fZ')
                item = {
                    'time': tm.strftime('%H:%M'),
                    'waf': 0,
                    'ips': 0,
                    'ads': 0,
                    'apt': 0
                }
                for d in t.count_per_dev.buckets:
                    if d.key == 'adssec':
                        item['ads'] = d.doc_count
                    if d.key == 'tpips':
                        item['ips'] = d.doc_count
                    if d.key == 'wafsec':
                        item['waf'] = d.doc_count
                attack_trends.append(item)
        except Exception, e:
            print "query attack_trends failed %s", e
        return attack_trends


    def dev_stastics(self, hours=12):
        device_types = {}
        end_time = datetime.now() #datetime.strptime('2019-06-12 06:00:00', '%Y-%m-%d %H:%M:%S')
        start_time = end_time - timedelta(hours=hours)
        start_time_str = start_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        end_time_str = end_time.strftime('%Y-%m-%dT%H:%M:%S.%fZ')

        q = Q('bool',
              must=[
                  Q('range', **{'@timestamp': {'gte': start_time_str, 'lte': end_time_str}})
              ])
        waf_ms = MultiSearch(using=self.es, index='titan-secdev-wafsec-*')
        waf_s1 = Search().query(q)[:0]
        waf_s1.aggs.metric('distinct_host', 'cardinality', field='host')
        waf_s2 = Search().query(q).filter('term', action='Block')[:0]
        waf_ms = waf_ms.add(waf_s1)
        waf_ms = waf_ms.add(waf_s2)

        ips_ms = MultiSearch(using=self.es, index='titan-secdev-tpips-*')
        ips_s1 = Search().query(q)[:0]
        ips_s1.aggs.metric('distinct_host', 'cardinality', field='host')
        ips_s2 = Search().query(q).filter('term', action='Block')[:0]
        ips_ms = ips_ms.add(ips_s1)
        ips_ms = ips_ms.add(ips_s2)

        ads_search = Search(using=self.es, index='titan-secdev-adssec-*').query(q)[:0]
        ads_search.aggs.metric('distinct_host', 'cardinality', field='host')

        waf_responses = waf_ms.execute()
        waf_total = waf_responses[0].hits.total
        device_types['waf'] = {
            'device_count': waf_responses[0].aggregations.distinct_host.value,
            'blocks': waf_responses[1].hits.total,
            'alarms': waf_total - waf_responses[1].hits.total
        }

        ips_responses = ips_ms.execute()
        ips_total = ips_responses[0].hits.total
        device_types['ips'] = {
            'device_count': ips_responses[0].aggregations.distinct_host.value,
            'blocks': ips_responses[1].hits.total,
            'alarms': ips_total - ips_responses[1].hits.total
        }

        ads_response = ads_search.execute()
        device_types['ads'] = {
            'device_count': ads_response.aggregations.distinct_host.value,
            'blocks': 0,
            'alarms': ads_response.hits.total
        }
        device_types['apt'] = {
            'device_count': 0,
            'blocks': 0,
            'alarms': 0
        }
        return device_types

    def security_response_stastics(self, days=60):

        result = {
            'change_count': 0,
            'change_rate': 0,
            'total': 0,
            'total_fixed': 0,
            'day_count': []
        }

        end_time = datetime.now()
        start_time = end_time - timedelta(days=days)

        mongo = Mongodb()
        db = mongo.conn()
        total = db.incident.find({'status': {'$ne': 8}}).count()
        total_fixed = db.incident.find({'status': {'$in': [3, 6, 7]}}).count()
        day_aggs_pipeline = [
            {'$match': {'$and': [{'status': {'$in': [1, 2, 4, 5]}}, {'gmt_created': {'$gte': start_time}}]}},
            {'$group': {
                '_id': {'$dateToString': {'format': "%m-%d", 'date': "$gmt_created"}},
                'count': {'$sum': 1}
            }}
        ]
        day_aggs = list(db.incident.aggregate(day_aggs_pipeline))
        day_fixed_aggs_pipeline = [
            {'$match': {'$and': [{'status': {'$in': [3, 6, 7]}}, {'gmt_created': {'$gte': start_time}}]}},
            {'$group': {
                '_id': {'$dateToString': {'format': "%m-%d", 'date': "$gmt_created"}},
                'count': {'$sum': 1}
            }}
        ]
        day_fixed_aggs = list(db.incident.aggregate(day_fixed_aggs_pipeline))

        day_count = []
        while not start_time > end_time:
            time = start_time.strftime(u'%m-%d')
            data = {
                'time': time,
                'fixed': 0,
                'unfix': 0
            }
            for da in day_aggs:
                if da['_id'] == time:
                    data['unfix'] = da.get('count', 0)
            for dfa in day_fixed_aggs:
                if dfa['_id'] == time:
                    data['fixed'] = dfa.get('count', 0)
            day_count.append(data)
            start_time = start_time + timedelta(days=1)
        result['total'] = total
        result['total_fixed'] = total_fixed
        today_count = day_count[-1]['unfix'] + day_count[-1]['fixed']
        lastday_count = day_count[-2]['unfix'] + day_count[-2]['fixed']
        result['day_count'] = day_count[-7:]
        result['change_count'] = today_count - lastday_count
        if lastday_count != 0:
            result['change_rate'] = float(result['change_count'])/float(lastday_count)
        elif result['change_count'] == 0:
            result['change_rate'] = 0
        else:
            result['change_rate'] = 1
        print '*****', result
        return result

    def last_incident(self, seconds=40):
        result = []
        end_time = datetime.now()
        start_time = end_time - timedelta(seconds=seconds)
        mongo = Mongodb()
        db = mongo.conn()
        res = db.incident.find({'$and': [{'status': {'$ne': 8}}, {'gmt_created': {'$gte': start_time}}]})\
            .sort([('gmt_created', -1)])
        for item in res:
            handlers = []
            for h in item['handlers']:
                user = db.user.find_one({'_id': h})
                handlers.append(user['username'])

            team = db.team.find_one({'_id': item['team']})
            data = {
                'event_name': item['desc'],
                'handler': ','.join(handlers),
                'handler_team': team['name'],
                'level': item['level']
            }
            result.append(data)
        return result

if __name__ == '__main__':

    hkes = HkbeaSoc()
    res = hkes.last_incident()
    print json.dumps(res)