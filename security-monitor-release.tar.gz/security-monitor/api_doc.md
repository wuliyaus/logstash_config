## 安全态势感知大屏接口


接口为websocket，具体如下：


### 1. 统计图表接口

#### URL /socket/v1/statistics

```json 
{
	"device_types": {
		"waf": {
			"alarms": 100,
			"blocks": 10,
			"device_count": 3
		},
		"ads": {
			"alarms": 1876,
			"blocks": 876,
			"device_count": 3
		},
		"apt": {
			"alarms": 918,
			"blocks": 0,
			"device_count": 8
		},
		"ips": {
			"alarms": 3000,
			"blocks": 1000,
			"device_count": 5
		}
	},
	"security_response": {
		"change_count": -10,
		"total_fixed": 500,
		"total": 610,
		"day_count": [{
			"fixed": 3,
			"unfix": 0,
			"time": "2019-06-01"
		}, {
			"fixed": 1,
			"unfix": 0,
			"time": "2019-06-02"
		}, {
			"fixed": 3,
			"unfix": 2,
			"time": "2019-06-03"
		}, {
			"fixed": 4,
			"unfix": 0,
			"time": "2019-06-04"
		}, {
			"fixed": 3,
			"unfix": 1,
			"time": "2019-06-05"
		}, {
			"fixed": 3,
			"unfix": 3,
			"time": "2019-06-06"
		}, {
			"fixed": 2,
			"unfix": 2,
			"time": "2019-06-07"
		}],
		"change_rate": -0.003
	},
	"attack_trends": [{
		"waf": 100,
		"ips": 300,
		"ads": 600,
		"apt": 10,
		"time": "01:00"
	}, {
		"waf": 200,
		"ips": 400,
		"ads": 500,
		"apt": 9,
		"time": "02:00"
	}, {
		"waf": 600,
		"ips": 200,
		"ads": 900,
		"apt": 25,
		"time": "03:00"
	}, {
		"waf": 201,
		"ips": 1002,
		"ads": 3001,
		"apt": 1,
		"time": "04:00"
	}, {
		"waf": 901,
		"ips": 2121,
		"ads": 1212,
		"apt": 0,
		"time": "05:00"
	}, {
		"waf": 100,
		"ips": 300,
		"ads": 600,
		"apt": 3,
		"time": "06:00"
	}, {
		"waf": 123,
		"ips": 312,
		"ads": 555,
		"apt": 1,
		"time": "07:00"
	}, {
		"waf": 444,
		"ips": 555,
		"ads": 666,
		"apt": 7,
		"time": "08:00"
	}, {
		"waf": 123,
		"ips": 321,
		"ads": 654,
		"apt": 4,
		"time": "09:00"
	}, {
		"waf": 222,
		"ips": 344,
		"ads": 877,
		"apt": 0,
		"time": "10:00"
	}],
	"attack_countries": [{
		"count": 1313213213121,
		"cca2": "CN",
		"name": "\u4e2d\u56fd"
	}, {
		"count": 999991231231,
		"cca2": "US",
		"name": "\u7f8e\u56fd"
	}, {
		"count": 8112312311,
		"cca2": "CA",
		"name": "\u52a0\u62ff\u5927"
	}, {
		"count": 70000123,
		"cca2": "JP",
		"name": "\u65e5\u672c"
	}, {
		"count": 66512111,
		"cca2": "TH",
		"name": "\u6cf0\u56fd"
	}],
	"attack_types": [{
		"count": 8000000,
		"name": "web scanner"
	}, {
		"count": 7800000,
		"name": "DDoS Attack"
	}, {
		"count": 6711111,
		"name": "Backdoor"
	}, {
		"count": 6511111,
		"name": "Bot Spider"
	}, {
		"count": 1231231,
		"name": "Virus"
	}]
}


```

### 2. 攻击事件

#### URL /socket/v1/attacks

其中，geo_point 第一个是经度，第二是纬度。

```json

[
    {
        "attack_type":"SQLi",
        "ip":"165.121.213.111",
        "region":"中国 北京",
        "geo_point":[
            116.4,
            39.9
        ]
    },
    {
        "attack_type":"XSS",
        "ip":"165.121.213.112",
        "region":"加拿大 多伦多",
        "geo_point":[
            -75.42,
            45.27
        ]
    },
    {
        "attack_type":"DDoS",
        "ip":"165.121.213.1",
        "region":"俄罗斯 莫斯科",
        "geo_point":[
            37.35,
            55.45
        ]
    },
    {
        "attack_type":"Webshell",
        "ip":"165.121.213.4",
        "region":"苏丹",
        "geo_point":[
            32.35,
            15.31
        ]
    },
    {
        "attack_type":"XSS",
        "ip":"165.121.213.7",
        "region":"西班牙 马德里",
        "geo_point":[
            -3.45,
            40.25
        ]
    },
    {
        "attack_type":"DDoS",
        "ip":"165.121.213.8",
        "region":"瑞典",
        "geo_point":[
            18.03,
            59.2
        ]
    },
    {
        "attack_type":"Backdoor",
        "ip":"165.121.213.9",
        "region":"以色列",
        "geo_point":[
            35.12,
            31.47
        ]
    }
]


```

### 3. 应急事件推送

#### URL /socket/v1/incident


```json

{
    "event_name":"未通过堡垒机登录服务器",
    "handler":"Leo",
    "handler_team":"数据组",
    "level":3
}

```
